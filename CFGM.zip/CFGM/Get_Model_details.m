function [MAPE,X0F,r] = Get_Model_details( F,X0,nf)
%GET_MODEL_DETAILS �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
switch F  
    case 'EGM'
        [MAPE,X0F]=EGM(X0,nf);
        r=1;
    case 'DGM'
        [MAPE,X0F]=DGM(X0,nf);
        r=1;
    case 'ODGM'
        [MAPE,X0F]=ODGM(X0,nf);
        r=1;
    case 'EDGM'
        [MAPE,X0F]=EDGM(X0,nf);
        r=1;
    case 'CFEGM'
        fobj=@CFEGM;
        [MAPE,X0F,r]=PSO_CFEGM(X0,fobj,nf);
    case 'CFDGM'
        fobj=@CFDGM;
        [MAPE,X0F,r]=PSO_CFDGM(X0,fobj,nf);
    case 'CFODGM'
        fobj=@CFODGM;
        [MAPE,X0F,r]=PSO_CFODGM(X0,fobj,nf);
    case 'CFEDGM'
        fobj=@CFEDGM;
        [MAPE,X0F,r]=PSO_CFEDGM(X0,fobj,nf);
end
end

function  [MAPE,X0F,r]=PSO_CFEGM(X0,fobj,nf)
    [r,pmin]=PSO(X0,fobj,nf);
    [MAPE,X0F]=CFEGM(r,X0,nf);
end
function  [MAPE,X0F,r]=PSO_CFDGM(X0,fobj,nf)
    [r,pmin]=PSO(X0,fobj,nf);
    [MAPE,X0F]=CFDGM(r,X0,nf);
end
function  [MAPE,X0F,r]=PSO_CFODGM(X0,fobj,nf)
    [r,pmin]=PSO(X0,fobj,nf);
    [MAPE,X0F]=CFODGM(r,X0,nf);
end
function  [MAPE,X0F,r]=PSO_CFEDGM(X0,fobj,nf)
    [r,pmin]=PSO(X0,fobj,nf);
    [MAPE,X0F]=CFEDGM(r,X0,nf);
end

